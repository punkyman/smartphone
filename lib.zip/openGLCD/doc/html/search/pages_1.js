var searchData=
[
  ['configuration',['Configuration',['../page_configuring.html',1,'index']]]
];
