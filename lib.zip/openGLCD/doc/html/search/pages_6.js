var searchData=
[
  ['licensing',['Licensing',['../page_license.html',1,'index']]]
];
