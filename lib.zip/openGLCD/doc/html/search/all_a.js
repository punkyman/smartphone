var searchData=
[
  ['left',['Left',['../classglcd.html#a080bff92b271be07d5d8257a2368bdbf',1,'glcd']]],
  ['licensing',['Licensing',['../page_license.html',1,'index']]]
];
