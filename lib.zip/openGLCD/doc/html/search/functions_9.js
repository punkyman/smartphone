var searchData=
[
  ['selectfont',['SelectFont',['../classg_text.html#af0565c110fd46054e32c27c371488f27',1,'gText']]],
  ['setareamode',['SetAreaMode',['../classg_text.html#a21aee7ba91a65aca71f6065fb8c1ed31',1,'gText']]],
  ['setbacklight',['SetBacklight',['../classglcd___device.html#a4778f387f8cdf518367f171a0db0a012',1,'glcd_Device']]],
  ['setdisplaymode',['SetDisplayMode',['../classglcd.html#a3cd01bf3d558fcc1889cd04a459cda7a',1,'glcd']]],
  ['setdot',['SetDot',['../classglcd___device.html#a6e25bf6d05ac3ee64be669118ef7c9d0',1,'glcd_Device']]],
  ['setfontcolor',['SetFontColor',['../classg_text.html#a0ad923e1304a9e2b24a4737a00802d4c',1,'gText']]],
  ['setpixels',['SetPixels',['../classglcd___device.html#aae54b1d03e950c63f2cecca0fea6d0b5',1,'glcd_Device']]],
  ['stringwidth',['StringWidth',['../classg_text.html#a2de77ec64f7378eae581d40050ec822c',1,'gText::StringWidth(const char *str)'],['../classg_text.html#a97e6a2c9d6d6e1285c6ec6c8de1e88e0',1,'gText::StringWidth(String &amp;str)']]],
  ['stringwidth_5fp',['StringWidth_P',['../classg_text.html#ae9bc1c1cdb2baed6b26c9a781f98c1fc',1,'gText']]]
];
