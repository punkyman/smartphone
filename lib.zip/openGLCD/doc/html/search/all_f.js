var searchData=
[
  ['readdata',['ReadData',['../classglcd___device.html#abe22f47712e6a01c65e1f5e4b1023028',1,'glcd_Device']]],
  ['right',['Right',['../classglcd.html#a6f1db2d3e921d6c346eb537abfac886b',1,'glcd']]]
];
