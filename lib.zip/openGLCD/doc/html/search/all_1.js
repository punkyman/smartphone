var searchData=
[
  ['black',['BLACK',['../group__glcd___device__enum.html#ga7b3b25cba33b07c303f3060fe41887f6',1,'glcd_Device.h']]],
  ['bottom',['Bottom',['../classglcd.html#a2889982b5ff6ab529deb8b239362e516',1,'glcd']]]
];
