var modules =
[
    [ "glcd_Device enumerations", "group__glcd___device__enum.html", "group__glcd___device__enum" ],
    [ "openGLCD enumerations", "group__glcd__enum.html", "group__glcd__enum" ]
];