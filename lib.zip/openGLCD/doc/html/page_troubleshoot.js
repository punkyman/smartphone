var page_troubleshoot =
[
    [ "Diagnostic Sketch", "page__g_l_c_ddiags.html", null ]
];