This is the excellent MemoryFree library from http://www.arduino.cc/playground/Code/AvailableMemory.

I am hosting it here so there is a quick and easy way to pull it down.

(20 Mar 2015) Repository updated with code from http://playground.arduino.cc/code/AvailableMemory
