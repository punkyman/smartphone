//
// openGLCD build information
// This headerfile is automatically generated
//

#ifndef __openGLCD_Buildinfo_h__
#define __openGLCD_Buildinfo_h__

#define GLCD_GLCDLIB_BUILD_LIBNAMESTR	"openGLCD"
#define GLCD_GLCDLIB_BUILD_DATESTR	"Sat Aug 20 15:09:55 CDT 2016"
#define GLCD_GLCDLIB_BUILD_REVSTR	"1.0rc3"
#define GLCD_GLCDLIB_BUILD_BUILDSTR	"v1.0rc3"
#endif
